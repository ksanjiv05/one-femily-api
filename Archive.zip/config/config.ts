import { Secret } from "jsonwebtoken";

export const SECRET_KEY: Secret =
  "jcefhfurhchasjxbwedgyewgdqewbytewyudqewdqed6qs8732e234e2346hg";
export const DB_URL: string =
  "mongodb+srv://kumarsanjiv0005:ApoQsK0otgANsWy5@cluster0.gdozhlf.mongodb.net/ARCMSDB?retryWrites=true&w=majority"; //"mongodb+srv://sanjiv:Aahw7JvAc33qsdwz@cluster0.88t4fy9.mongodb.net/RCMSDB?retryWrites=true&w=majority"
export const DB_URL_DEV: string = "127.0.0.1:27017";

export const DB_NAME: string = "ELPSDB";
export const HOST = "http://localhost:4000/api/v1/static/";

//Aahw7JvAc33qsdwz
//kumarsanjiv0005
//ApoQsK0otgANsWy5
